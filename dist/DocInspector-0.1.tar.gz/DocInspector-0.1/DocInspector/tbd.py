from DocInspector import DocStats
from DocInspector.Collectors import *


def collectFromFile(fileId, service, http, incrementSize, unsafeLevel):
    # Build docstats
    docStats = DocStats(incrementSize)
    docStats.general.id = fileId

    # Get general stats
    collectGeneralStats(docStats, service)

    # Get individual stats
    collectIndividualStats(docStats, service)

    #  Get timeline stats
    collectTimelineStats(docStats, service)

    if unsafeLevel > 0:
        # Get unsafe Stats
        collectUnsafeStats(docStats, http, unsafeLevel > 1)
    return docStats
