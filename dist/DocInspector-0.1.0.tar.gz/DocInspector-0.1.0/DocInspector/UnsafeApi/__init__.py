from .Document import Document  # Document is the only class the developer needs to interact with directly.
