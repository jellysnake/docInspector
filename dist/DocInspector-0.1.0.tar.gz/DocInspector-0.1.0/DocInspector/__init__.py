from .DocStats import DocStats
from .LoadStats import collectFromFile, collectFromFolder, tryCollectFromId
from .OutputStats import outputStats